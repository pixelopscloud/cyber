#!/bin/bash
echo "Cleaning old files..."
rm -rf /var/www/html/*
