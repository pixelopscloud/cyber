#!/bin/bash
echo "Restarting web server..."
systemctl restart httpd
